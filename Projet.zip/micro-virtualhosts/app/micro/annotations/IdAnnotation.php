<?php
namespace micro\annotations;
/**
 * Annotation Id
 * @author jc
 * @version 1.0.0.1
 * @package annotations
 */
class IdAnnotation extends BaseAnnotation{

}
