<?php
namespace micro\annotations;

/**
 * Annotation ManyToOne
 * @author jc
 * @version 1.0.0.2
 * @package annotations
 */
class ManyToOneAnnotation extends BaseAnnotation{
}
